﻿namespace app2;
public class Class1
{
    public string GetString()
    {
        return "Hello World this is app2";
    }
}
