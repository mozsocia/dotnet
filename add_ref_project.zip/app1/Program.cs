﻿// See https://aka.ms/new-console-template for more information
using app2;

Class1 c = new Class1();

Console.WriteLine(c.GetString());
Console.WriteLine("Hello, World!");
